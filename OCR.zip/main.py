import easyocr
reader = easyocr.Reader(['ch_tra', 'en'])
#result = reader.readtext('chinese_tra.jpg')

reader.readtext('chinese_tra.jpg', detail = 0)