import numpy as np
import gradio as gr
import easyocr

reader = easyocr.Reader(['en']) # for english
#reader = easyocr.Reader(['hi','en']) # for hindi 
#reader = easyocr.Reader(['te','en']) # for telugu

#for (bbox, text, prob) in result:
#    print(f'Text: {text}, Probability: {prob}')    

def sepia(input_img):
    result = reader.readtext(input_img, detail = 0)
    return result

demo = gr.Interface(sepia, gr.Image(), "text")
if __name__ == "__main__":
    demo.launch()